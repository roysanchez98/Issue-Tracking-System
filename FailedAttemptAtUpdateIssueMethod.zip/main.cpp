#include <iostream>
#include "issueMethods.h"
#include <time.h>
#include <random>

using namespace std;

int main(){
    srand((unsigned) time(0));
    issueMenu();
    return 0;
}